// +k8s:deepcopy-gen=package,register
// +k8s:defaulter-gen=TypeMeta
// +k8s:openapi-gen=true

// +groupName=openshiftcontrolplane.config.openshift.io
// Package v1 is the v1 version of the API.
package v1
